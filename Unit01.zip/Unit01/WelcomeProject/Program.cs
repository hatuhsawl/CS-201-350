﻿using System;

/**
 * @author Catie Hattesohl
 * Class Program displays a welcome messageto the console window. */           
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to C#!");
    }
}
